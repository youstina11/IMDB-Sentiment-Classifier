# IMDB Sentiment Classifier

### Binary Sentiment Classification with Logistic Regression

![Project cover](images/cover.png)

## Description

An end-to-end binary sentiment classifier for the IMDB 50K movie reviews dataset. Raw review text is transformed into Bag-of-Words features and classified using a Logistic Regression model trained by minimizing Binary Cross-Entropy loss. The project covers preprocessing, mathematical derivations, model training with convergence analysis, full evaluation (accuracy, precision, recall, F1, ROC-AUC, threshold tuning, error analysis), model interpretability (top predictive words), a reusable inference function, and an independent SQL-based verification layer — achieving **87.6% test accuracy** and **0.94 ROC-AUC**.

**بالعربي:** موديل تصنيف مشاعر ثنائي (إيجابي/سلبي) على 50 ألف ريفيو من IMDB، باستخدام Bag-of-Words وLogistic Regression مدرّب بخسارة Binary Cross-Entropy، ومزوّد بتحليل رياضي، تقييم كامل، تفسير للموديل، ودالة تنبؤ جاهزة، بالإضافة لطبقة تحقق بلغة SQL. حقق دقة 87.6% وROC-AUC يساوي 0.94.

## Pipeline

![Project pipeline](images/pipeline.png)

## Contents

| File | Description |
|---|---|
| `IMDB_Logistic_Regression.ipynb` | Full executed Jupyter notebook — all 5 tasks, run top to bottom with outputs preserved |
| `Project_Report.docx` | Written report summarizing methodology, results, and SQL verification |
| `model_results.db` | SQLite database with the test-set predictions used for the SQL analysis layer |
| `images/cover.png` | Project cover illustration |
| `images/pipeline.png` | Project pipeline diagram |

## Key Results

| Metric | Value |
|---|---|
| Accuracy | 87.62% |
| Precision | 87.44% |
| Recall | 87.86% |
| F1-Score | 87.65% |
| ROC-AUC | 0.9410 |
| Test BCE (Log Loss) | 0.3993 |

**Algorithm:** Logistic Regression &nbsp;|&nbsp; **Dataset:** IMDB (50K Reviews) &nbsp;|&nbsp; **Loss:** Binary Cross-Entropy &nbsp;|&nbsp; **Framework:** Scikit-Learn &nbsp;|&nbsp; **Seed:** 42
